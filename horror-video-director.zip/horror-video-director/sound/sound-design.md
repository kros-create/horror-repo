# Sound Design for Horror Video

Horror is at least half audio. A weak image with strong sound is still scary; the reverse is not true.

## The four layers
1. **Bed** - constant low drone or room tone. Keep it just above silence. See `sound_bed` per style in `styles/styles.json`.
2. **Foley** - small real sounds that anchor the scene: door hiss, cloth, breathing, keys.
3. **Stingers** - single loud hits. Maximum one per video.
4. **Silence** - drop everything for 1-3 seconds before the reveal. Silence reads as danger.

## Mix targets (starting points, adjust by ear)
| Element | Level vs. narration |
|---|---|
| Narration | reference (about -16 LUFS integrated for the final) |
| Bed / music | 12-18 dB under narration (the default `--music-volume 0.15`) |
| Foley | 6-10 dB under narration |
| Stinger | at most the same level as narration; never clip |

## Per-scene sound plan
Put it in each scene's `sfx` field. Format: bed change, foley, accent.
Example: `"door hiss, soft idle rumble"` -> `"all sound drops out for a beat, then a low sustained tone"`.

## Silence beats (use at least two)
- Right before the first oddity is confirmed
- Right before the reveal image

## Voice
- Calm, low, steady. Never shout. Do not act scared; the voice is the safe one.
- 2.0-2.6 words per second. Leave a half-second gap after the scariest sentence.
- One voice for the whole video. For H2 use a flatter, "recorded log" read.

## Music and effects sourcing
Use only audio you own, generated yourself with a tool whose terms allow YouTube use, or licensed with clear terms. Keep a `credits.txt` with source and license for each file. Do not use commercial songs, film scores or game audio.

## Quick recipes
| Moment | Recipe |
|---|---|
| Something wrong enters | cut bed to half, add one faint foley sound |
| Realization | bed swells for 2 s, then drops to near silence |
| Reveal | 1 s silence, a single low tone, hold |
| Final image | bed fades out under the last line; no music tail |

## Per-scene files in the build
`hvd.py build` mixes, per scene, `audio` (narration) and optional `sfx_file` (volume `sfx_volume`, default 0.7), then lays a music bed underneath the whole video with `--music`.
