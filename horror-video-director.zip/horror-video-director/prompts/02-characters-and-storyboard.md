# Prompt 2 - Characters and Storyboard

## A. Character design (do this before any storyboard)
```
Design the recurring characters for a horror video in style [H1-H6] (see styles/styles.json for the look).
For each character give one line: body shape, head, eyes, clothing, the ONE accent color, and one signature habit.
Keep designs simple enough that an image model reproduces them identically in every scene.
Then describe front, side and back views in plain text so I can generate three reference images.
Characters in the story: [LIST]
```

Generate the reference images, approve them, and attach the approved image to every later generation if the tool allows.

## B. Turn the script into a storyboard JSON
```
Convert this narration script into a storyboard.json that follows templates/storyboard.json.
For every scene fill: id, duration (seconds), narration (exact text), description (one location, one idea, one image),
action (what moves), camera, motion (one of creep, push_in, pull_out, pan_left, pan_right, shake, static),
mood, sfx, characters (ids from the characters list).
Rules:
- One scene = one location = one image.
- Each description includes exactly one wrong detail.
- Vary motion; no more than 3 scenes in a row with the same motion.
- Durations sum to about [TOTAL] seconds and respect 2.0-2.6 words per second.
- Characters are referenced by id only; do not repeat their design in descriptions.
Style: [H1-H6]. Aspect: [16:9 or 9:16].
Return only valid JSON.
```

## C. Review the storyboard
```
Review this storyboard against story/horror-craft.md. List problems only:
hook late, no wrong detail in a scene, two scenes with identical composition, a twist not foreshadowed,
a scene that needs two images, durations that do not fit the narration.
[STORYBOARD JSON]
```

Then run:
```
python scripts/hvd.py validate path/to/storyboard.json
```
