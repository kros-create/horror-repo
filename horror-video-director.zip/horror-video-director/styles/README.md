# Animation Styles

Six locked looks. Each is defined machine-readably in [`styles.json`](styles.json) (the prefix, negative prompt and palette that `hvd.py prompts` injects into every scene). This file explains how to choose and use them.

| ID | Name | Mood | Cost to keep consistent | Best first video |
|---|---|---|---|---|
| H1 | Void Stickman | cold, minimal, creepypasta | lowest | yes |
| H2 | Found Footage Glitch | analog, voyeuristic | low | second |
| H3 | Gothic Ink Storybook | folkloric, period | medium | folk horror |
| H4 | Red Room Creepypasta | cinematic dread, entity | medium | forest / road stories |
| H5 | Cursed Crayon | innocence gone wrong | low | short twists |
| H6 | Liminal Rooms | empty, uncanny | low | atmosphere pieces |

## How to choose
- Voice-driven story with a lot of narration -> **H1**
- "Someone filmed this" story -> **H2**
- Past century, village, curse -> **H3**
- Woods, roads, a thing that follows -> **H4**
- Child narrator or nursery theme -> **H5**
- No plot, all atmosphere, endless place -> **H6**

## Consistency rules (all styles)
1. Every image prompt starts with the style's `style_prefix`. Never paraphrase it.
2. Characters are defined once in the storyboard and appended automatically.
3. One accent color only (the last color in each style's palette).
4. Use the same aspect ratio for every scene in a video.
5. Generate a reference image first. Attach it to every later generation if the tool supports reference images.
6. If a scene drifts, regenerate just that scene; do not restyle the whole video.

## Motion defaults
| Motion | Use for |
|---|---|
| creep | slow dread, almost unnoticeable push in |
| push_in | reveals, realizations |
| pull_out | isolation, final images |
| pan_left / pan_right | showing a space, following a line of sight |
| shake | panic, found-footage (H2 default) |
| static | stillness, innocence (H5 default) |

## H1 Void Stickman
**Look**: pure black, white stick figures with constant stroke, one blood-red accent on the important object.
**Do**: lots of negative space, tiny figure in a big void, extreme close-ups of one eye.
**Don't**: add color besides red, add shading, add backgrounds with detail.
**Great for**: first channel video. Cheapest to generate and the easiest to keep consistent.

## H2 Found Footage Glitch
**Look**: green-grey VHS image, scanlines, camera timestamp, a pale figure in the background.
**Do**: put a figure in the background of a "normal" scene; cut audio out for a beat.
**Don't**: use realistic faces or brand names; add bright daylight.
**Great for**: logs, night shifts, security cameras.

## H3 Gothic Ink Storybook
**Look**: sepia parchment, crosshatch, torn edges, candle-warm glow against ink-black shadows.
**Do**: composition like a book plate; text-free illustrations; slow side pans.
**Don't**: modern props; neon colors; photoreal textures.
**Great for**: folklore and "old book" stories.

## H4 Red Room Creepypasta
**Look**: teal-and-crimson, fog, long shadows, a faceless tall silhouette far away.
**Do**: place the entity in the distance, smaller each time it appears closer.
**Don't**: show the entity's face or close detail; use warm bright light.
**Great for**: series with a recurring monster.

## H5 Cursed Crayon
**Look**: waxy crayon on rough paper, primary colors that feel wrong, one tall black scribbled figure.
**Do**: let the drawing change between scenes; keep narration childlike and calm.
**Don't**: any graphic or harmful depiction involving children. Imply, never show.
**Great for**: 1-3 minute twists.

## H6 Liminal Rooms
**Look**: yellow carpet, buzzing fluorescent light, endless corridors, one tiny figure.
**Do**: perfect one-point perspective; one new detail per scene.
**Don't**: crowds, clutter, outdoor daylight.
**Great for**: atmosphere pieces and "the building keeps going" stories.

## Adding your own style
Copy an entry in `styles.json`, give it a new ID (`H7`), fill `style_prefix`, `negative`, `palette` (background first, accent last), `motion_default`, then run `python tests/test_hvd.py` to check the file still loads.
