# Story Ideas (original loglines)

All ideas are original seeds, safe for a general audience (no gore). Remix them; do not reuse verbatim across a whole channel. Format: **title** - logline. *Best style / length.*

## Everyday spaces turned wrong
1. **The Last Bus** - A night passenger realizes every stop adds someone wearing her face. *H1 / 2 min* (full storyboard in `examples/`)
2. **Floor 13.5** - An elevator button appears between 13 and 14, and the building's staff pretend not to see it. *H6 / 3 min*
3. **The Night Shift Counter** - A 24-hour shop cashier notices the same customer buying the same thing every night, one hour earlier each time. *H2 / 5 min*
4. **Vacancy** - A motel room is booked for tonight under the narrator's name, in handwriting that is not theirs. *H1 / 3 min*
5. **Self Checkout** - The machine keeps saying "unexpected item in the bagging area" and the item is getting bigger. *H2 / 1 min*
6. **The Quiet Carriage** - On a train with a strict silence rule, someone is whispering the passengers' names in order. *H4 / 3 min*

## Technology and analog horror
7. **Recording 0031** - A tenant finds a security tape of their apartment, filmed from inside the walls. *H2 / 6 min*
8. **Do Not Wave Back** - A baby monitor shows a figure waving from the corner. The rule: never wave back. *H2 / 2 min*
9. **Delivery Confirmed** - A parcel arrives daily with a photo of the doorstep, taken from one step closer each time. *H2 / 3 min*
10. **Smart Home, Dumb Rules** - A home assistant starts giving house rules that sound like warnings. *H1 / 4 min*
11. **Channel 0** - A TV channel between channels broadcasts the viewer's living room, a few seconds in the future. *H2 / 4 min*

## Folklore and old places
12. **The Lamplighter's Count** - A village must keep exactly 40 lanterns lit. One night there are 41. *H3 / 5 min*
13. **What the Well Returns** - Everything dropped into the well comes back changed, until the village drops something it should not have. *H3 / 4 min*
14. **Saint of the Salt Road** - Travelers who leave an offering reach the inn. Those who do not reach it earlier. *H3 / 3 min*
15. **The Bell That Rings Itself** - A chapel bell tolls once for every villager who will leave before morning. *H3 / 4 min*
16. **Hollow Harvest** - A farm's scarecrows are placed each autumn by a family that never leaves the house. *H3 / 5 min*

## Forests, roads and the tall thing
17. **Mile Marker 66** - A hitchhiker is always standing at the mile marker, a little closer to the road each night. *H4 / 4 min*
18. **Campfire Rules** - Seven rules left on a trail sign, each one broken by the previous camper. *H4 / 5 min*
19. **Do Not Count the Trees** - A hiking group counts the same number of trees going in and out, plus one. *H4 / 3 min*
20. **The Radio Only Plays at Night** - A lone ranger hears a voice reading tomorrow's search party list. *H4 / 6 min*

## Childhood and innocence
21. **Marnie Lives Under the Stairs** - A child's imaginary friend knows facts about the house nobody told her. *H5 / 3 min*
22. **The Drawing Got Taller** - A parent notices a figure in every crayon drawing getting closer to the little girl's drawn self. *H5 / 2 min*
23. **Sleepover Rules** - Five kids play a game with one rule: whoever turns the light on loses. *H5 / 4 min*
24. **The Music Box Stops** - The lullaby only plays when someone is about to be taken back. *H5 / 1 min*

## Liminal and impossible spaces
25. **The Hallway Home** - A man takes a shortcut and the corridor never ends, but the door numbers count down to his own apartment. *H6 / 4 min*
26. **Level Pool** - An empty indoor pool where the water level matches how close it is to you. *H6 / 3 min*
27. **Office After Hours** - The cleaning crew's checklist includes one line nobody can read aloud. *H6 / 4 min*
28. **Stairwell B** - Each floor looks identical except for one new thing the narrator did not notice before. *H6 / 5 min*

## Series and long-form hooks
29. **Five Nights Alone** - A house-sitter's log, each night adding one rule that was not on the list the night before. *H2 / 12 min*
30. **The Rulebook Anthology** - Five short stories, each a "welcome pack" for a workplace with sinister rules. *H1 / 12 min*
31. **Letters to the Night Guard** - A guard reads letters sent to a building that closed years ago. *H3 / 10 min*
32. **The Archive of Small Wrong Things** - An archivist catalogues objects that appeared in the wrong century. *H3 / 8 min*

## Remix prompts
- Take any ordinary routine and add one rule that must never be broken.
- Take a safety instruction (signs, warnings, announcements) and make it a clue.
- Take a loop (commute, shift, ritual) and make the viewer discover the loop late.
- Take the thing the narrator is sure of (a count, a time, a name) and make it off by one.

## Pitching checklist
- Can the wrong thing be shown in one image?
- Can the twist be hinted at twice without ruining it?
- Does the final image work as a thumbnail?
- Is there a line that makes a good title?
