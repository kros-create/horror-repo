# Publishing Notes for YouTube

These are practical reminders, not legal advice. YouTube's rules change; read the current policies before you publish.

## Content safety for horror
- Keep graphic violence, gore and shock content out. Implied and atmospheric horror is both safer and scarier.
- Do not depict harm to children. Child narrators and nursery themes (H5) are fine as atmosphere; never show harm.
- Do not present real crimes, victims or tragedies as entertainment.
- Do not target or identify real private individuals.
- Add a plain content note in the description: "Fictional horror story. No gore."
- Consider marking the video as not made for kids. Age restrictions may apply; follow the prompts YouTube gives.

## AI disclosure
YouTube asks creators to disclose realistic altered or synthetic content in some cases (for example realistic-looking people or events). Stylized stick-figure animation is usually not realistic, but check the current wording of the disclosure question when you upload, and answer honestly. State in the description that visuals and narration are AI-assisted.

## Originality and "inauthentic" content
Channels made of mass-produced, near-identical, low-effort videos can be judged repetitive or inauthentic and may lose monetization. To stay on the right side:
- Write a real story with a point of view for every video.
- Vary structure, style and length across a series.
- Add your own editing, voice direction and sound design.
- Do not reuse a script across videos or copy other people's stories.

## Music, effects and voice
- Use only audio you made, generated with a tool whose terms allow it, or properly licensed.
- Keep `credits.txt` per project: file, source, license, link.
- If you clone a real person's voice, you need their permission.

## Thumbnails
- Do not use gore, real faces, or misleading images.
- One wrong detail, one accent color, three words maximum.

## Before you upload (checklist)
- [ ] No gore, no harm to children, no real victims
- [ ] Description has a content note and an AI-assistance statement
- [ ] Music and effects licensed, credits saved
- [ ] Synthetic-content disclosure answered correctly
- [ ] Captions uploaded (`out/captions.srt`) if not burned in
- [ ] Title is accurate; thumbnail matches the video
