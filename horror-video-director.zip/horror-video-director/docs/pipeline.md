# Production Pipeline

Two ways to make a video from this repo. Both start with the same story work; they differ in how visuals are produced.

```
idea -> loglines -> script -> characters -> storyboard.json -> validate -> prompts
                                                                   |
                    A: generate clips scene by scene, edit by hand  |
                    B: images + narration + hvd.py build -> MP4  ---+
```

## What you need

| Step | Mode A | Mode B |
|---|---|---|
| Story, script, storyboard | any AI chat assistant | any AI chat assistant |
| Run scripts | optional | Python 3.9+ |
| Visuals | an AI video generator | an AI image generator (one still per scene) |
| Voice | optional | a text-to-speech service or your own recording |
| Assembly | a video editor | ffmpeg (`hvd.py build`) |

Services charge by their own plans. Check pricing before generating many scenes.

## Setup (Mode B)
```
git clone <your fork of this repo>
cd horror-video-director
python scripts/hvd.py --help
ffmpeg -version          # must exist
pip install pillow       # only for the placeholders command
```

## Steps in detail

### 1. Create a project
```
python scripts/hvd.py init my-first-horror --style H1 --aspect 16:9
```
This creates `projects/my-first-horror/` with `storyboard.json` and empty `images/`, `audio/`, `clips/`, `out/` folders.

### 2. Develop the story
Use `prompts/01-story-and-script.md`. Save the approved narration.

### 3. Lock characters
Use `prompts/02-characters-and-storyboard.md` (part A). Generate and approve reference images. Store them in `images/refs/`.

### 4. Write the storyboard
Fill `storyboard.json` (part B of the same prompt). Then:
```
python scripts/hvd.py validate projects/my-first-horror/storyboard.json
```
Fix every error. Read every warning.

### 5. Prompts
```
python scripts/hvd.py prompts projects/my-first-horror/storyboard.json
```
This writes `prompts.md` with an image prompt and a video prompt per scene.

### 6A. Mode A - generate clips
Paste each video prompt into your video generator. Attach the character reference. Save clips as `clips/s01.mp4`, `clips/s02.mp4`, ... and edit with your preferred editor. Use the `sfx` field as the sound plan and `sound/sound-design.md` for the mix.

### 6B. Mode B - generate assets and build
1. Generate each image from its image prompt, save as `images/s01.png`...
2. Generate narration per scene, save as `audio/s01.wav`...
   If you only have one long narration file, split it by scene or set `duration` per scene and use a single music bed.
3. Dry run with no images yet:
   ```
   python scripts/hvd.py placeholders projects/my-first-horror/storyboard.json
   python scripts/hvd.py build projects/my-first-horror/storyboard.json
   ```
4. Preview: copy the storyboard and keep only the first 3 scenes; build; check style, voice, pacing.
5. Full build:
   ```
   python scripts/hvd.py build projects/my-first-horror/storyboard.json --music bed.mp3 --burn-captions
   ```
   Output: `out/<title>.mp4` and `out/captions.srt`.

If a scene has a generated clip, set `"video": "clips/s05.mp4"` on that scene and the build uses the clip instead of the still. You can mix both in one video.

### 7. Package and publish
Use `prompts/04-packaging-and-shorts.md`. Read `docs/youtube-policy.md` before uploading.

## Scene fields understood by `hvd.py`
| Field | Meaning |
|---|---|
| id | unique scene id |
| duration | seconds (used when no audio file; otherwise audio length + `pad`, default 0.4 s) |
| narration | spoken text (drives captions and density checks) |
| description, action, camera, mood | go into image/video prompts |
| motion | creep, push_in, pull_out, pan_left, pan_right, shake, static |
| sfx | sound plan note (prompts only) |
| image / video / audio / sfx_file | files relative to the storyboard |
| sfx_volume | volume of `sfx_file`, default 0.7 |
| characters | ids from the storyboard's `characters` |

## Rework cheaply
Only the scene that is wrong needs regenerating. Replace its file and run `build` again; approved scenes are reused as they are on disk.

## Cost control
- Start with H1 or H5 (fewest details to keep consistent).
- Preview 3 scenes before generating 40.
- Use one still per scene in Mode B; generate clips only for the 3-5 most important scenes.
