# Horror Craft for Faceless Video

Short rules that make an AI-assembled horror video feel written instead of generated.

## 1. Dread beats jump scares
A jump scare lasts one second and wears off. Dread lasts the whole video and brings people back. Use at most one loud stinger per video, and only after at least 30 seconds of quiet.

## 2. The three-question hook
In the first 8 seconds, make the viewer ask one of:
- **What is that?** ("The bus had one more passenger at every stop.")
- **Why would anyone do that?** ("I was paid to sit in a house and never answer the door.")
- **What happens next?** ("The photo had been taken from inside my bedroom.")

Open mid-situation. Never open with "Hi guys" or the channel intro.

## 3. Rule of one wrong thing
Every scene gets exactly one wrong detail: a reflection out of sync, a warm seat, an extra chair. Stack them slowly. If everything is wrong, nothing is.

## 4. Escalate on a ladder
Normal -> odd -> wrong -> personal -> inescapable. Each rung must be more personal than the last. The best twist makes the viewer reread the earlier rungs.

## 5. Specific beats vague
"A man in the corner" is weaker than "a man in a bus-driver cap who never turns his body." Specific nouns and one measured number ("the third stop") sound true.

## 6. Narration voice
- Short sentences. Spoken, not literary.
- Past tense for a told story, present tense for found-footage.
- 2.0-2.6 words per second. Leave a half-second pause after the scariest line.
- Never explain the monster. The explanation is always weaker than the viewer's imagination.

## 7. Retention curve
| Time | Job |
|---|---|
| 0-8 s | hook |
| 8-45 s | normal world, first oddity |
| 45 s - 70% | ladder of escalations, one every 20-40 s |
| 70-90% | reveal |
| last 10% | quiet final image or loop line |

For videos over 8 minutes, add a mini-cliffhanger every 2-3 minutes.

## 8. Endings that work
- **The loop**: the last line repeats the first, now with new meaning.
- **The swap**: the narrator is the thing they feared.
- **The doorway left open**: danger is resolved but one detail proves it is not.
- **The quiet confirmation**: a small proof the reader suspected (a tidy "I was right").

Avoid: "it was all a dream", sudden unexplained death of everyone, a lecture.

## 9. What not to show
No gore, no suffering for its own sake, no real tragedies, no depiction of harm to children. Keep the line at implication. It is safer for YouTube and more frightening anyway.

## 10. Quality checklist
- [ ] One accent color in the whole video
- [ ] One wrong thing per scene
- [ ] Hook in first 8 seconds
- [ ] Two silent beats
- [ ] A final image that can be a thumbnail
- [ ] The twist is foreshadowed by at least two earlier details
