import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import hvd  # noqa: E402

EXAMPLE = ROOT / "examples" / "the-last-bus" / "storyboard.json"


def load_example():
    return json.loads(EXAMPLE.read_text(encoding="utf-8"))


class StylesTest(unittest.TestCase):
    def test_all_styles_complete(self):
        styles = hvd.load_styles()
        self.assertEqual(sorted(styles), ["H1", "H2", "H3", "H4", "H5", "H6"])
        for sid, s in styles.items():
            for key in ("name", "summary", "palette", "style_prefix", "negative", "motion_default", "sound_bed"):
                self.assertTrue(s.get(key), f"{sid} missing {key}")
            self.assertIn(s["motion_default"], hvd.MOTIONS)
            self.assertIn("no gore", s["negative"])


class ValidateTest(unittest.TestCase):
    def test_example_is_valid(self):
        errors, warnings, total = hvd.validate(load_example(), EXAMPLE.parent)
        self.assertEqual(errors, [])
        self.assertAlmostEqual(total, 97, delta=1)

    def test_catches_problems(self):
        sb = load_example()
        sb["style"] = "H9"
        sb["scenes"][1]["id"] = sb["scenes"][0]["id"]
        sb["scenes"][2]["motion"] = "spin"
        sb["scenes"][3]["characters"] = ["ghost"]
        sb["scenes"][4]["duration"] = 0
        errors, _, _ = hvd.validate(sb, EXAMPLE.parent)
        text = "\n".join(errors)
        self.assertIn("unknown style", text)
        self.assertIn("duplicate scene id", text)
        self.assertIn("unknown motion", text)
        self.assertIn("not defined", text)
        self.assertIn("positive 'duration'", text)

    def test_dense_narration_warns(self):
        sb = load_example()
        sb["scenes"][0]["duration"] = 2
        _, warnings, _ = hvd.validate(sb, EXAMPLE.parent)
        self.assertTrue(any("too dense" in w for w in warnings))

    def test_missing_files_only_checked_on_request(self):
        sb = load_example()
        self.assertEqual(hvd.validate(sb, EXAMPLE.parent)[0], [])
        with tempfile.TemporaryDirectory() as d:
            errors, _, _ = hvd.validate(sb, Path(d), check_files=True)
        self.assertEqual(len([e for e in errors if "missing file" in e]), 12)


class PromptsTest(unittest.TestCase):
    def test_prompts_contain_style_and_characters(self):
        sb = load_example()
        style = hvd.load_styles()[sb["style"]]
        sc = sb["scenes"][0]
        ip = hvd.image_prompt(sb, sc, style)
        self.assertTrue(ip.startswith(style["style_prefix"]))
        self.assertIn("Mara:", ip)
        self.assertIn("red scarf", ip)
        self.assertIn("16:9 frame", ip)
        self.assertIn("Avoid:", ip)
        vp = hvd.video_prompt(sb, sc, style, 7)
        self.assertIn("Camera:", vp)
        self.assertIn("about 7 seconds", vp)

    def test_render_all_scenes(self):
        text = hvd.render_prompts(load_example(), EXAMPLE.parent)
        self.assertEqual(text.count("**Image prompt:**"), 12)
        self.assertEqual(text.count("**Video prompt (Director Mode):**"), 12)


class SrtTest(unittest.TestCase):
    def test_srt_is_monotonic_and_covers_all_text(self):
        sb = load_example()
        srt = hvd.render_srt(sb, EXAMPLE.parent)
        blocks = [b for b in srt.strip().split("\n\n") if b.strip()]
        self.assertGreater(len(blocks), 20)
        last_end = -1.0

        def secs(t):
            h, m, rest = t.split(":")
            s, ms = rest.split(",")
            return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000

        for b in blocks:
            lines = b.split("\n")
            start, end = [secs(x.strip()) for x in lines[1].split("-->")]
            self.assertLess(start, end)
            self.assertGreaterEqual(start, last_end - 1e-6)
            last_end = end
        spoken = " ".join(" ".join(b.split("\n")[2:]) for b in blocks)
        self.assertEqual(spoken.split(), " ".join(s["narration"] for s in sb["scenes"]).split())

    def test_srt_time_format(self):
        self.assertEqual(hvd.srt_time(3661.5), "01:01:01,500")


class InitTest(unittest.TestCase):
    def test_init_creates_project(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(hvd.main(["init", "demo", "--style", "H3", "--aspect", "9:16", "--dir", d]), 0)
            sb = json.loads((Path(d) / "demo" / "storyboard.json").read_text())
            self.assertEqual((sb["style"], sb["aspect"], sb["title"]), ("H3", "9:16", "demo"))
            for sub in ("images", "audio", "clips", "out"):
                self.assertTrue((Path(d) / "demo" / sub).is_dir())
            self.assertEqual(hvd.main(["init", "demo", "--dir", d]), 1)  # already exists

    def test_template_validates(self):
        sb = json.loads(hvd.TEMPLATE_PATH.read_text())
        self.assertEqual(hvd.validate(sb, hvd.TEMPLATE_PATH.parent)[0], [])


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "ffmpeg not installed")
class BuildTest(unittest.TestCase):
    def test_end_to_end_build(self):
        try:
            import PIL  # noqa: F401
        except ImportError:
            self.skipTest("Pillow not installed")
        with tempfile.TemporaryDirectory() as d:
            proj = Path(d)
            sb = load_example()
            sb["scenes"] = sb["scenes"][:3]
            for sc in sb["scenes"]:
                sc["duration"] = 2
            (proj / "storyboard.json").write_text(json.dumps(sb))
            self.assertEqual(hvd.main(["placeholders", str(proj / "storyboard.json")]), 0)
            # narration for scene 1 as a 1.5 s tone, to exercise audio-driven duration + sfx mixing
            (proj / "audio").mkdir()
            subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "sine=frequency=220:duration=1.5",
                            str(proj / "audio" / "s01.wav")], check=True)
            sb["scenes"][0]["audio"] = "audio/s01.wav"
            sb["scenes"][0]["sfx_file"] = "audio/s01.wav"
            (proj / "storyboard.json").write_text(json.dumps(sb))
            out = proj / "out" / "test.mp4"
            rc = hvd.main(["build", str(proj / "storyboard.json"), "-o", str(out)])
            self.assertEqual(rc, 0)
            self.assertTrue(out.is_file())
            dur = hvd.probe_duration(out)
            self.assertAlmostEqual(dur, 1.9 + 2 + 2, delta=0.4)
            streams = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(out)],
                                     capture_output=True, text=True).stdout.split()
            self.assertIn("video", streams)
            self.assertIn("audio", streams)
            self.assertTrue((proj / "out" / "captions.srt").is_file())

    def test_all_motions_render(self):
        for m in hvd.MOTIONS:
            z, x, y = hvd.zoompan_expr(m, 60)
            self.assertTrue(z and x and y)


if __name__ == "__main__":
    unittest.main()
