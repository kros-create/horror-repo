# Story Structures by Length

Pick the sheet that matches the target runtime. Scene counts assume one still image per scene with slow camera moves (Mode B). For generated clips (Mode A) use one clip per beat.

## 30-60 seconds (Shorts, 9:16)
| Beat | Time | Content |
|---|---|---|
| Hook | 0-3 s | the wrong thing, already happening |
| Setup | 3-15 s | who, where, one rule |
| Escalation | 15-40 s | the rule is broken, it gets personal |
| Sting | 40-55 s | reveal or twist in one image |
| Loop | last 3 s | line that makes people rewatch |

6-10 scenes, 4-6 seconds each. One location.

## 2-3 minutes (the sweet spot to start)
1. Hook (8 s)
2. Normal world (20 s)
3. First oddity (20 s)
4. Second oddity, bigger (25 s)
5. The rule or the discovery (25 s)
6. Point of no return (20 s)
7. Reveal (25 s)
8. Final image (10 s)

12-20 scenes, 7-10 seconds each. See `examples/the-last-bus/`.

## 5-8 minutes
Three acts with a midpoint reversal.
- **Act 1 (0-20%)**: hook, ordinary life, the inciting oddity
- **Act 2a (20-50%)**: investigation, each clue stranger than the last, one false relief
- **Midpoint (50%)**: the viewer learns the situation is not what it looked like
- **Act 2b (50-80%)**: the threat becomes personal, a plan fails
- **Act 3 (80-100%)**: confrontation without explanation, then the final image

30-50 scenes. Add a cliffhanger line at roughly every 2 minutes.

## 10-15 minutes
Compilation or episodic structure is safer than one very long story:
- **Anthology**: 3-5 short stories linked by a frame (a radio host, a night guard reading letters). Each story is a 2-3 minute sheet above.
- **Escalating series**: one location, five nights. Night 1 is normal, night 5 is inescapable. Every night ends on a wrong detail.
- **Found-footage log**: dated entries that degrade in tone and spelling as the narrator unravels (H2 works best).

## Twist types
| Type | Example shape |
|---|---|
| The narrator is the threat | the "witness" is the entity |
| The place is the monster | the building rearranges to keep you in |
| Time loop | the final line is the first line |
| Replacement | everyone is already replaced, including the viewer-proxy |
| Rule reversal | the safety rule was the trap |
| Quiet proof | a single object proves the unbelievable account |

## One-page beat template
```
LOGLINE:      A [ordinary person] must [do ordinary thing] but [one wrong rule].
HOOK LINE:
THE WRONG THING (scene 1):
THE LADDER:   odd -> wrong -> personal -> inescapable
THE TWIST:
FINAL IMAGE:
TITLE IDEAS:  (3)
```
