#!/usr/bin/env python3
"""hvd - Horror Video Director helper CLI.

Subcommands:
  init          scaffold a new project folder from the template
  validate      check a storyboard for problems before you spend money on generation
  prompts       write image + video prompts for every scene (style + character lock applied)
  srt           write an SRT caption file timed to the storyboard
  placeholders  draw dark placeholder frames so you can test the pipeline for free (needs Pillow)
  build         assemble images/clips + narration + sfx + music + captions into an MP4 (needs ffmpeg)

Only the Python standard library is required, except `placeholders` (Pillow) and `build` (ffmpeg).
"""
import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STYLES_PATH = ROOT / "styles" / "styles.json"
TEMPLATE_PATH = ROOT / "templates" / "storyboard.json"

RESOLUTIONS = {"16:9": (1920, 1080), "9:16": (1080, 1920), "1:1": (1080, 1080)}
MOTIONS = ("creep", "push_in", "pull_out", "pan_left", "pan_right", "shake", "static")
# Slow, deliberate horror narration is roughly 1.8-2.6 words per second.
WPS_WARN_HIGH = 3.2
WPS_WARN_LOW = 1.0


class HvdError(Exception):
    pass


def load_styles():
    return json.loads(STYLES_PATH.read_text(encoding="utf-8"))


def load_storyboard(path):
    p = Path(path)
    if not p.is_file():
        raise HvdError(f"storyboard not found: {p}")
    try:
        return json.loads(p.read_text(encoding="utf-8")), p.parent
    except json.JSONDecodeError as e:
        raise HvdError(f"storyboard is not valid JSON: {e}")


def probe_duration(path):
    """Return media duration in seconds via ffprobe, or None."""
    if not shutil.which("ffprobe") or not Path(path).is_file():
        return None
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=nw=1:nk=1", str(path)],
        capture_output=True, text=True)
    try:
        return float(out.stdout.strip())
    except ValueError:
        return None


def resolve_durations(sb, base):
    """Scene length = narration audio length if the file exists, else the 'duration' field."""
    durations = []
    for sc in sb["scenes"]:
        d = None
        if sc.get("audio"):
            d = probe_duration(base / sc["audio"])
            if d is not None:
                d += float(sc.get("pad", 0.4))  # small breath after the line
        if d is None:
            d = float(sc.get("duration", 0))
        durations.append(d)
    return durations


# ---------------------------------------------------------------- validate

def validate(sb, base, check_files=False):
    errors, warnings = [], []
    styles = load_styles()
    if not sb.get("title"):
        errors.append("missing title")
    if sb.get("style") not in styles:
        errors.append(f"unknown style '{sb.get('style')}' (choose from {', '.join(styles)})")
    if sb.get("aspect") not in RESOLUTIONS:
        errors.append(f"aspect must be one of {', '.join(RESOLUTIONS)}")
    scenes = sb.get("scenes") or []
    if not scenes:
        errors.append("no scenes")
    char_ids = {c.get("id") for c in sb.get("characters", [])}
    seen = set()
    total = 0.0
    for i, sc in enumerate(scenes, 1):
        sid = sc.get("id") or f"#{i}"
        if sid in seen:
            errors.append(f"{sid}: duplicate scene id")
        seen.add(sid)
        words = len(re.findall(r"\b[\w'’-]+\b", sc.get("narration", "")))
        dur = float(sc.get("duration", 0) or 0)
        if not sc.get("narration"):
            warnings.append(f"{sid}: no narration (silent scene)")
        if dur <= 0 and not sc.get("audio"):
            errors.append(f"{sid}: needs a positive 'duration' or an 'audio' file")
        if dur > 0 and words:
            wps = words / dur
            if wps > WPS_WARN_HIGH:
                warnings.append(f"{sid}: narration too dense ({words} words in {dur}s, {wps:.1f} w/s) - lengthen scene or cut words")
            elif wps < WPS_WARN_LOW and dur > 4:
                warnings.append(f"{sid}: very sparse ({words} words in {dur}s) - fine for a deliberate silence, otherwise tighten")
        if sc.get("motion", "creep") not in MOTIONS:
            errors.append(f"{sid}: unknown motion '{sc.get('motion')}' (use {', '.join(MOTIONS)})")
        for cid in sc.get("characters", []):
            if cid not in char_ids:
                errors.append(f"{sid}: character '{cid}' is not defined in 'characters'")
        if not sc.get("description"):
            warnings.append(f"{sid}: no visual 'description' (prompts will be empty)")
        if check_files:
            has_clip = sc.get("video") and (base / sc["video"]).is_file()
            if not has_clip:
                image = sc.get("image") or f"images/{sc.get('id', '')}.png"
                if not (base / image).is_file():
                    errors.append(f"{sid}: missing file {image}")
            for key in ("video", "audio", "sfx_file"):
                if sc.get(key) and not (base / sc[key]).is_file():
                    errors.append(f"{sid}: missing file {sc[key]}")
        total += dur
    if scenes and sc_first_hook_late(scenes):
        warnings.append("hook: the first scene is long; aim for a hook line within the first 8-10 seconds")
    return errors, warnings, total


def sc_first_hook_late(scenes):
    try:
        return float(scenes[0].get("duration", 0)) > 12
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------- prompts

def character_block(sb, sc):
    chars = {c["id"]: c for c in sb.get("characters", [])}
    parts = []
    for cid in sc.get("characters", []):
        c = chars.get(cid)
        if c:
            parts.append(f"{c.get('name', cid)}: {c['design']}")
    return "; ".join(parts)


def image_prompt(sb, sc, style):
    bits = [style["style_prefix"], sc.get("description", "").strip()]
    cb = character_block(sb, sc)
    if cb:
        bits.append(f"Characters (keep identical in every scene): {cb}")
    if sc.get("mood"):
        bits.append(f"Mood: {sc['mood']}")
    bits.append(f"{sb.get('aspect', '16:9')} frame")
    bits.append(f"Avoid: {style['negative']}")
    return ". ".join(b.rstrip(". ") for b in bits if b) + "."


def video_prompt(sb, sc, style, duration):
    bits = [style["style_prefix"], sc.get("description", "").strip()]
    cb = character_block(sb, sc)
    if cb:
        bits.append(f"Characters (keep identical): {cb}")
    if sc.get("action"):
        bits.append(f"Action: {sc['action']}")
    if sc.get("camera"):
        bits.append(f"Camera: {sc['camera']}")
    if sc.get("mood"):
        bits.append(f"Mood: {sc['mood']}")
    bits.append(f"Clip length about {duration:g} seconds, {sb.get('aspect', '16:9')}")
    if sc.get("sfx"):
        bits.append(f"Audio: {sc['sfx']}")
    bits.append(f"Avoid: {style['negative']}")
    return ". ".join(b.rstrip(". ") for b in bits if b) + "."


def render_prompts(sb, base):
    style = load_styles()[sb["style"]]
    durs = resolve_durations(sb, base)
    lines = [f"# Prompts - {sb['title']}", "",
             f"Style **{sb['style']} {style['name']}** | aspect {sb.get('aspect', '16:9')}", ""]
    for sc, d in zip(sb["scenes"], durs):
        lines += [f"## {sc['id']}  ({d:g}s)", "",
                  f"**Narration:** {sc.get('narration', '')}", "",
                  "**Image prompt:**", "", "```", image_prompt(sb, sc, style), "```", "",
                  "**Video prompt (Director Mode):**", "", "```", video_prompt(sb, sc, style, d), "```", ""]
    return "\n".join(lines)


# ---------------------------------------------------------------- srt

def srt_time(t):
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def chunk_words(text, max_words=6):
    """Split narration into caption chunks, breaking at sentence ends first, then evenly by length."""
    chunks = []
    for sentence in re.split(r"(?<=[.!?;:])\s+", text.strip()):
        words = sentence.split()
        if not words:
            continue
        parts = -(-len(words) // max_words)  # ceil
        size = -(-len(words) // parts)
        chunks += [" ".join(words[i:i + size]) for i in range(0, len(words), size)]
    return chunks


def render_srt(sb, base):
    durs = resolve_durations(sb, base)
    t, idx, out = 0.0, 1, []
    for sc, d in zip(sb["scenes"], durs):
        chunks = chunk_words(sc.get("narration", ""))
        if chunks:
            speaking = max(d - 0.4, 0.5)
            total_words = sum(len(c.split()) for c in chunks)
            cur = t
            for c in chunks:
                span = speaking * len(c.split()) / total_words
                out.append(f"{idx}\n{srt_time(cur)} --> {srt_time(cur + span)}\n{c}\n")
                idx += 1
                cur += span
        t += d
    return "\n".join(out)


# ---------------------------------------------------------------- placeholders

def make_placeholders(sb, base):
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        raise HvdError("Pillow is required: pip install pillow")
    w, h = RESOLUTIONS[sb.get("aspect", "16:9")]
    styles = load_styles()
    bg = styles[sb["style"]]["palette"][0]
    fg = styles[sb["style"]]["palette"][1]
    accent = styles[sb["style"]]["palette"][-1]
    made = 0
    for sc in sb["scenes"]:
        rel = sc.get("image") or f"images/{sc['id']}.png"
        dest = base / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        img = Image.new("RGB", (w, h), bg)
        d = ImageDraw.Draw(img)
        try:
            font = ImageFont.load_default(size=max(24, h // 22))
        except TypeError:
            font = ImageFont.load_default()
        # tiny stick figure for scale
        cx, cy, r = w // 2, int(h * 0.55), h // 24
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=fg, width=4)
        d.line([cx, cy + r, cx, cy + r * 4], fill=fg, width=4)
        d.line([cx, cy + r * 2, cx - r * 2, cy + r * 3], fill=fg, width=4)
        d.line([cx, cy + r * 2, cx + r * 2, cy + r * 3], fill=fg, width=4)
        d.line([cx, cy + r * 4, cx - r * 2, cy + r * 7], fill=fg, width=4)
        d.line([cx, cy + r * 4, cx + r * 2, cy + r * 7], fill=fg, width=4)
        d.text((w // 12, h // 12), f"{sc['id']}  PLACEHOLDER", fill=accent, font=font)
        y = h // 12 + h // 14
        for line in textwrap.wrap(sc.get("description", ""), width=60 if w >= h else 30)[:6]:
            d.text((w // 12, y), line, fill=fg, font=font)
            y += h // 22
        img.save(dest)
        made += 1
    return made


# ---------------------------------------------------------------- build (ffmpeg)

def zoompan_expr(motion, frames):
    d = max(frames, 1)
    centre_x = "iw/2-(iw/zoom/2)"
    centre_y = "ih/2-(ih/zoom/2)"
    table = {
        "creep":    (f"1+0.07*on/{d}", centre_x, centre_y),
        "push_in":  (f"1+0.18*on/{d}", centre_x, centre_y),
        "pull_out": (f"1.18-0.18*on/{d}", centre_x, centre_y),
        "pan_left": ("1.12", f"(iw-iw/zoom)*(1-on/{d})", centre_y),
        "pan_right": ("1.12", f"(iw-iw/zoom)*on/{d}", centre_y),
        "shake":    ("1.06", f"{centre_x}+sin(on*1.7)*10", f"{centre_y}+cos(on*2.3)*8"),
        "static":   ("1", centre_x, centre_y),
    }
    return table[motion]


def run_ffmpeg(args, cwd=None):
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"] + args
    res = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)
    if res.returncode != 0:
        raise HvdError("ffmpeg failed:\n" + " ".join(cmd) + "\n" + res.stderr.strip())


def build_scene(sb, sc, dur, base, tmp, idx, vignette=True, grain=False):
    w, h = RESOLUTIONS[sb.get("aspect", "16:9")]
    fps = int(sb.get("fps", 30))
    frames = int(round(dur * fps))
    out = tmp / f"scene_{idx:03d}.mp4"

    # vignette is computed once (eval=init); grain is per-frame random noise and costs about 3x render time
    fx = []
    if vignette:
        fx.append("vignette=PI/4:eval=init")
    if grain:
        fx.append("noise=alls=7:allf=t")
    vf_tail = ",".join(fx + ["format=yuv420p"])
    fade = f"fade=t=in:st=0:d=0.3,fade=t=out:st={max(dur - 0.3, 0):.3f}:d=0.3"

    inputs, vlabel = [], None
    if sc.get("video") and (base / sc["video"]).is_file():
        inputs += ["-i", str(base / sc["video"])]
        vfilter = (f"[0:v]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},"
                   f"fps={fps},tpad=stop_mode=clone:stop_duration={dur:.3f},trim=duration={dur:.3f},"
                   f"setpts=PTS-STARTPTS,{vf_tail},{fade}[v]")
    else:
        img = base / (sc.get("image") or f"images/{sc['id']}.png")
        if not img.is_file():
            raise HvdError(f"{sc['id']}: image not found: {img} (run `hvd.py placeholders` to test without images)")
        inputs += ["-loop", "1", "-framerate", str(fps), "-i", str(img)]
        z, x, y = zoompan_expr(sc.get("motion", "creep"), frames)
        sw, sh = w * 3 // 2 // 2 * 2, h * 3 // 2 // 2 * 2  # 1.5x working size keeps zoompan smooth and fast
        vfilter = (f"[0:v]scale={sw}:{sh}:force_original_aspect_ratio=increase,crop={sw}:{sh},"
                   f"zoompan=z='{z}':x='{x}':y='{y}':d={frames}:s={w}x{h}:fps={fps},"
                   f"{vf_tail},{fade}[v]")

    audio_labels = []
    n = 1
    if sc.get("audio") and (base / sc["audio"]).is_file():
        inputs += ["-i", str(base / sc["audio"])]
        audio_labels.append(f"[{n}:a]aformat=sample_rates=48000:channel_layouts=stereo,apad[a{n}]")
        n += 1
    if sc.get("sfx_file") and (base / sc["sfx_file"]).is_file():
        inputs += ["-i", str(base / sc["sfx_file"])]
        vol = float(sc.get("sfx_volume", 0.7))
        audio_labels.append(f"[{n}:a]aformat=sample_rates=48000:channel_layouts=stereo,volume={vol},apad[a{n}]")
        n += 1
    if not audio_labels:
        inputs += ["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo"]
        audio_labels.append(f"[{n}:a]anull[a{n}]")
        n += 1
    labels = "".join(f"[a{i}]" for i in range(1, n))
    if n - 1 > 1:
        amix = f"{labels}amix=inputs={n - 1}:duration=longest:dropout_transition=0,volume={n - 1}[aout]"
    else:
        amix = f"{labels}anull[aout]"
    fc = ";".join([vfilter] + audio_labels + [amix])

    run_ffmpeg(inputs + ["-filter_complex", fc, "-map", "[v]", "-map", "[aout]",
                         "-t", f"{dur:.3f}", "-r", str(fps),
                         "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                         "-c:a", "aac", "-ar", "48000", "-ac", "2", "-b:a", "192k", str(out)])
    return out


def cmd_build(sb, base, args):
    if not shutil.which("ffmpeg"):
        raise HvdError("ffmpeg not found. Install it (https://ffmpeg.org) and try again.")
    errors, _, _ = validate(sb, base)
    if errors:
        raise HvdError("storyboard has errors, run `validate` first:\n  " + "\n  ".join(errors))
    durs = resolve_durations(sb, base)
    out_dir = base / "out"
    out_dir.mkdir(exist_ok=True)
    final = Path(args.output) if args.output else out_dir / f"{re.sub(r'[^A-Za-z0-9_-]+', '_', sb['title'])}.mp4"
    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        clips = []
        for i, (sc, d) in enumerate(zip(sb["scenes"], durs), 1):
            print(f"  scene {sc['id']} ({d:.1f}s)", flush=True)
            clips.append(build_scene(sb, sc, d, base, tmp, i, vignette=not args.no_fx, grain=args.grain))
        listfile = tmp / "list.txt"
        listfile.write_text("".join(f"file '{c.as_posix()}'\n" for c in clips), encoding="utf-8")
        joined = tmp / "joined.mp4"
        run_ffmpeg(["-f", "concat", "-safe", "0", "-i", str(listfile), "-c", "copy", str(joined)])

        srt_path = out_dir / "captions.srt"
        srt_path.write_text(render_srt(sb, base), encoding="utf-8")

        need_music = bool(args.music)
        need_burn = bool(args.burn_captions)
        if not need_music and not need_burn:
            shutil.copy(joined, final)
        else:
            cmd, vf = [], []
            cmd += ["-i", str(joined)]
            if need_music:
                cmd += ["-stream_loop", "-1", "-i", str(Path(args.music).resolve())]
            if need_burn:
                vf = ["-vf", "subtitles=captions.srt:force_style='Fontsize=14,Outline=2,Shadow=0,Alignment=2,MarginV=48'"]
            if need_music:
                fc = (f"[1:a]volume={args.music_volume}[m];"
                      "[0:a][m]amix=inputs=2:duration=first:dropout_transition=0,volume=2[aout]")
                maps = ["-filter_complex", fc, "-map", "0:v", "-map", "[aout]"]
                if need_burn:
                    maps = ["-filter_complex",
                            f"[0:v]subtitles=captions.srt:force_style='Fontsize=14,Outline=2,Shadow=0,Alignment=2,MarginV=48'[vout];{fc}",
                            "-map", "[vout]", "-map", "[aout]"]
                    vf = []
            else:
                maps = []
            enc = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "192k",
                   "-shortest", str(final.resolve())]
            run_ffmpeg(cmd + vf + maps + enc, cwd=str(out_dir))
    print(f"done: {final}")
    print(f"captions: {srt_path} (upload to YouTube if you did not burn them in)")


# ---------------------------------------------------------------- init

def cmd_init(args):
    styles = load_styles()
    if args.style not in styles:
        raise HvdError(f"unknown style {args.style}; choose from {', '.join(styles)}")
    dest = Path(args.dir) / args.name
    if dest.exists():
        raise HvdError(f"{dest} already exists")
    for sub in ("images", "audio", "clips", "out"):
        (dest / sub).mkdir(parents=True)
    sb = json.loads(TEMPLATE_PATH.read_text(encoding="utf-8"))
    sb["title"] = args.name
    sb["style"] = args.style
    sb["aspect"] = args.aspect
    (dest / "storyboard.json").write_text(json.dumps(sb, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"created {dest}/storyboard.json with style {args.style} ({styles[args.style]['name']})")
    print("next: ask your AI assistant to fill it in using skills/directing-horror-videos/SKILL.md")


# ---------------------------------------------------------------- main

def main(argv=None):
    ap = argparse.ArgumentParser(prog="hvd", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("init", help="scaffold a project")
    p.add_argument("name")
    p.add_argument("--style", default="H1")
    p.add_argument("--aspect", default="16:9", choices=list(RESOLUTIONS))
    p.add_argument("--dir", default="projects")

    for name, helptext in (("validate", "check a storyboard"), ("prompts", "write image+video prompts"),
                           ("srt", "write captions"), ("placeholders", "draw placeholder frames"),
                           ("build", "assemble the video")):
        q = sub.add_parser(name, help=helptext)
        q.add_argument("storyboard")
        if name == "validate":
            q.add_argument("--check-files", action="store_true")
        if name in ("prompts", "srt"):
            q.add_argument("-o", "--output")
        if name == "build":
            q.add_argument("-o", "--output")
            q.add_argument("--music", help="background music file (mixed quietly under narration)")
            q.add_argument("--music-volume", type=float, default=0.15)
            q.add_argument("--burn-captions", action="store_true", help="hard-code captions (needs ffmpeg with libass)")
            q.add_argument("--no-fx", action="store_true", help="skip the vignette")
            q.add_argument("--grain", action="store_true", help="add film grain (about 3x slower render)")

    args = ap.parse_args(argv)
    try:
        if args.cmd == "init":
            cmd_init(args)
            return 0
        sb, base = load_storyboard(args.storyboard)
        if args.cmd == "validate":
            errors, warnings, total = validate(sb, base, args.check_files)
            for w in warnings:
                print("warning:", w)
            for e in errors:
                print("error:  ", e)
            print(f"{len(sb.get('scenes', []))} scenes, about {total / 60:.1f} min, {len(errors)} errors, {len(warnings)} warnings")
            return 1 if errors else 0
        if args.cmd == "prompts":
            text = render_prompts(sb, base)
            dest = Path(args.output) if args.output else base / "prompts.md"
            dest.write_text(text, encoding="utf-8")
            print(f"wrote {dest}")
        elif args.cmd == "srt":
            text = render_srt(sb, base)
            dest = Path(args.output) if args.output else base / "out" / "captions.srt"
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(text, encoding="utf-8")
            print(f"wrote {dest}")
        elif args.cmd == "placeholders":
            print(f"drew {make_placeholders(sb, base)} placeholder frames")
        elif args.cmd == "build":
            cmd_build(sb, base, args)
        return 0
    except HvdError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
