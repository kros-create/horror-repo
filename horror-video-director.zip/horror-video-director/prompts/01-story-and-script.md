# Prompt 1 - Story and Script

Copy into any AI assistant. Replace the bracketed parts.

## A. Pitch three loglines
```
You are a horror story developer for faceless YouTube videos.
Give me 3 original loglines for a [LENGTH] horror video in style [H1-H6].
Constraints: no gore, no real people or real tragedies, one location, one wrong thing visible in the first image,
a twist I can foreshadow twice. For each logline give: hook line, the wrong thing, the twist, the final image, 3 title ideas.
Topic or theme (optional): [THEME]
```

## B. Write the narration script
```
Write the narration for the approved story below as a [LENGTH] horror video.
Rules:
- Spoken, short sentences. 2.0 to 2.6 words per second.
- Hook inside the first 8 seconds.
- Follow this beat sheet: [PASTE the matching sheet from story/story-structures.md]
- One wrong detail per scene, escalating: odd -> wrong -> personal -> inescapable.
- Never explain the monster. No "it was all a dream". No gore.
- Include two deliberate silent beats, marked [SILENCE 2s].
- Foreshadow the twist with at least two earlier details.
- End on a quiet final image or a loop line.
Output as a numbered list of scenes: scene id, estimated seconds, narration text only.
Story: [APPROVED LOGLINE AND TWIST]
```

## C. Tighten pass
```
Reduce this script to fit [N] seconds at 2.2 words per second. Keep the hook, the twist foreshadowing and the final line.
Cut explanation first, adjectives second. Return the script and the word count per scene.
[SCRIPT]
```

## D. Rewrite for spoken delivery
```
Rewrite for a calm, low, slow voice. Replace written phrasing with spoken phrasing. Add a half-second pause (a line break)
after the scariest sentence. Do not add new events. [SCRIPT]
```
