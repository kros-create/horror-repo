# Prompt 4 - Titles, Thumbnails, Description, Shorts

## Title and thumbnail
```
Give me 10 title options and 3 thumbnail concepts for this horror video.
Rules: no clickbait lies, no "gore" or "real" claims that are not true, under 60 characters.
Thumbnail: style [H1-H6], one wrong detail, one accent color, at most 3 words of text, readable at phone size.
Story: [LOGLINE]. Final image: [FINAL IMAGE].
```

## Description
```
Write a YouTube description for this horror video: 2-sentence hook with no spoilers, a content note ("fictional story, no gore"),
chapters if the video is longer than 5 minutes, a line stating the story is original fiction,
and a line stating that visuals and narration are AI-assisted. No hashtags beyond three.
[SCRIPT SUMMARY]
```

## Shorts cutdown
```
From this script pick the 45-second segment with the strongest hook and end it on the wrong detail, not the explanation.
Rewrite the first line as a hook, keep the rest under 110 words, and list which scenes to reuse in 9:16.
End with a loop line that leads back into the first line.
[SCRIPT]
```

## Series plan
```
Plan a 6-video series on a recurring location or entity in style [H1-H6].
Each video: logline, the new rule, the twist, and a one-line link to the previous video.
Escalate across the series; do not explain the entity until the last video.
```
