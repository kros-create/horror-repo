# Prompt 3 - Image and Video Generation

`python scripts/hvd.py prompts storyboard.json` writes these for you. This file explains the structure so you can edit them by hand.

## Image prompt (Mode B)
```
[STYLE PREFIX from styles.json]. [SCENE DESCRIPTION]. Characters (keep identical in every scene): [CHARACTER DESIGNS].
Mood: [MOOD]. [ASPECT] frame. Avoid: [NEGATIVE from styles.json].
```
Example (H1):
```
Minimalist 2D stick figure horror animation on a pure black background, white hand-drawn line art ... ominous silence.
A lone bus stop sign and a bench in an endless black void, one small stick figure waiting under a single weak streetlight cone.
Characters (keep identical in every scene): Mara: stick figure, round white head, two small black oval eyes, thin white line limbs, a small red scarf as the only color.
Mood: lonely, quiet, cold. 16:9 frame. Avoid: no gore, no realistic human faces, no text, ...
```

## Video clip prompt (Mode A)
```
[STYLE PREFIX]. [SCENE DESCRIPTION]. Characters (keep identical): [DESIGNS].
Action: [ACTION]. Camera: [CAMERA]. Mood: [MOOD]. Clip length about [N] seconds, [ASPECT].
Audio: [SFX]. Avoid: [NEGATIVE].
```

## Rules that save money
1. Generate scene 1 and scene 2 first. If the look is wrong, fix the style prefix before generating more.
2. Attach the approved character reference image to every generation.
3. Generate clips at their shortest useful length (4-8 s). Cut to music and narration in the edit.
4. Regenerate one scene at a time. Never regenerate approved scenes.
5. Keep a `prompts.md` and the approved output filenames together so a scene can be repeated exactly.

## Fixing common problems
| Problem | Fix |
|---|---|
| Character changes between scenes | attach the reference image; shorten the description; remove adjectives that describe the face |
| Too colorful | add "pure black background, only one accent color" and repeat the negative prompt |
| Looks cute instead of scary | remove "cute/cartoon" words; add "ominous silence, heavy vignette, negative space" |
| Gore or realistic faces appear | add "no realistic faces, stick figure only" to the negative prompt; simplify the description |
| Text appears in the image | add "no text, no letters, no numbers"; put any text in the edit instead |
| Motion looks jittery (video tools) | ask for "slow, smooth, minimal motion, locked camera" |
